//
//  ViewController.m
//  wuxiangundong
//
//  Created by mctc on 2018/3/8.
//  Copyright © 2018年 mctc. All rights reserved.
//

#import "ViewController.h"
#import "XDCollectionView.h"

#define imageP(name) [UIImage imageNamed:name]

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //创建轮播图view
    XDCollectionView *collectionView = [[XDCollectionView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, 270)];
    [self.view addSubview:collectionView];
    //添加图片数组
    NSArray *arr = @[imageP(@"HongKong"), imageP(@"HongKong1"), imageP(@"HongKong2"), imageP(@"HongKong3"), imageP(@"HongKong1")];
    collectionView.imageArray = arr;
    //点击图片触发
    collectionView.block = ^(NSInteger intValue) {
        NSLog(@"我点了第%zd张图片", intValue);
    };
    
    //当滑动tableview 轮播图不会停止滚动  当拖动轮播图时 轮播图停止滚动
    UITableView *table = [[UITableView alloc] initWithFrame:CGRectMake(0, 270 + 64 + 10, self.view.bounds.size.width, self.view.bounds.size.height - 270)];
    table.backgroundColor = [UIColor grayColor];
    [self.view addSubview:table];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
