//
//  XDCollectionView.h
//  wuxiangundong
//
//  Created by mctc on 2018/3/8.
//  Copyright © 2018年 mctc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XDFlowLayout : UICollectionViewFlowLayout

@end

/*
 ----------------------------------------------------------------------------------------------------------------
 */

// 点击图片的回调
typedef void (^ClickImageBlock) (NSInteger intValue);

@interface XDCollectionView : UIView
@property (nonatomic, strong) NSArray<UIImage *> *imageArray;

@property (nonatomic, copy) ClickImageBlock block;

/// 是否隐藏分页指示器
@property (nonatomic, assign) BOOL isHidePage;

@end

/*
 ----------------------------------------------------------------------------------------------------------------
 */

@interface XDCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) UIImage *image;
@end
