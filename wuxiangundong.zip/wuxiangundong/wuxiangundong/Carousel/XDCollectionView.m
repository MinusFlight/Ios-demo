//
//  XDCollectionView.m
//  wuxiangundong
//
//  Created by mctc on 2018/3/8.
//  Copyright © 2018年 mctc. All rights reserved.
//

#import "XDCollectionView.h"

@implementation XDFlowLayout

- (void)prepareLayout {
    [super prepareLayout];
    
    //设置cell大小
    self.itemSize = self.collectionView.bounds.size;
    //设置cell 之间的间距
    self.minimumLineSpacing = 0;
    self.minimumInteritemSpacing = 0;
    //滚动条
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.collectionView.showsVerticalScrollIndicator = NO;
    // 横向滚动
    self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    // 设置翻页
    self.collectionView.pagingEnabled = YES;
}

@end

/*
----------------------------------------------------------------------------------------------------------------
*/

#define KZuShu 3
// 设置轮播图单张停留时间
#define KTimeInterval 2

static NSString *cell_id = @"cell_id";
@interface XDCollectionView ()<UICollectionViewDelegate, UICollectionViewDataSource>
@property (nonatomic, strong) UICollectionView *collectionView;
/// 定时器
@property (nonatomic, copy) NSTimer *timer;

/// 分页指示器
@property (nonatomic, strong) UIPageControl *pageControl;

@end

@implementation XDCollectionView

// 记录轮播图的第一张距离
NSInteger minCountPX;
// 记录轮播图的最后一张距离
NSInteger maxCountPX;
- (void)setImageArray:(NSArray<UIImage *> *)imageArray {
    _imageArray = imageArray;
    
    _pageControl.numberOfPages = imageArray.count;//指定页面个数
    
    [self.collectionView reloadData];
    
    [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:(NSInteger)KZuShu*0.5] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    minCountPX  = _collectionView.contentOffset.x;
    maxCountPX = minCountPX + (imageArray.count-1) * self.bounds.size.width;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self makeCollectionViewUI];
    }
    return self;
}

- (void)makeCollectionViewUI {
    XDFlowLayout *flowLayout = [[XDFlowLayout alloc] init];
    
    self.collectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:flowLayout];
    //添加代理
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [self addSubview:_collectionView];
    
    [_collectionView registerClass:[XDCollectionViewCell class] forCellWithReuseIdentifier:cell_id];
    
    // 创建page
    self.pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, self.bounds.size.height - 50, self.bounds.size.width, 50)];
    _pageControl.currentPage = 0;//指定pagecontroll的值，默认选中的小白点（第一个）
    _pageControl.pageIndicatorTintColor = [UIColor blackColor];// 设置非选中页的圆点颜色
    _pageControl.currentPageIndicatorTintColor = [UIColor whiteColor]; // 设置选中页的圆点颜色
    [self addSubview:_pageControl];
    
    //设置定时器 让轮播图滚动
    _timer = [NSTimer timerWithTimeInterval:KTimeInterval repeats:YES block:^(NSTimer * _Nonnull timer) {
        
        [self.collectionView setContentOffset:CGPointMake(self.collectionView.contentOffset.x + self.bounds.size.width, 0) animated:YES];
    }];
    //添加到runloop中 启动定时器
    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return KZuShu;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.imageArray.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    XDCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cell_id forIndexPath:indexPath];
    // 传入图片
    cell.image = self.imageArray[indexPath.item];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"indexPath = %zd", indexPath.item);
    // 图片点击回调
    self.block(indexPath.item);
}

// 监听collectionView 的滚动
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    // 当前滚动距离
    CGPoint p = scrollView.contentOffset;
    // 让选中currentPage到中间再变化
    int page = (int)((p.x + scrollView.frame.size.width * 0.5) / scrollView.frame.size.width) % _imageArray.count;
    _pageControl.currentPage = page;

    // 判断是否是第一张往后滚
    if (p.x <= minCountPX - self.bounds.size.width) {
        // 关闭动画 偷偷的回到默认组的最后一张
        [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:(self.imageArray.count - 1) inSection:(NSInteger)KZuShu*0.5] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    }
    // 判断是否是最后一张往前滚
    if (p.x >= maxCountPX + self.bounds.size.width) {
        // 关闭动画 偷偷的回到默认组的第一张
        [self.collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:(NSInteger)KZuShu*0.5] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    }
    
    
}

// 当用户点击轮播图时 停止图片自己滚动
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [_timer invalidate];
}
// 当用户手指离开屏幕时 图片开始自己滚动
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    _timer = [NSTimer timerWithTimeInterval:KTimeInterval repeats:YES block:^(NSTimer * _Nonnull timer) {
        [self.collectionView setContentOffset:CGPointMake(self.collectionView.contentOffset.x + self.bounds.size.width, 0) animated:YES];
    }];
    
    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView {
    
}

- (void)setIsHidePage:(BOOL)isHidePage {
    _isHidePage = isHidePage;
    
    self.pageControl.hidden = isHidePage;
}

// view 退出时  停止timer 防止内存泄漏
- (void)dealloc {
    
    [_timer invalidate];
}

@end

/*
 ----------------------------------------------------------------------------------------------------------------
 */

@interface XDCollectionViewCell ()
@property (nonatomic, strong) UIImageView *imageview;
@end

@implementation XDCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor grayColor];
        self.imageview = [[UIImageView alloc] initWithFrame:self.bounds];
        self.imageview.contentMode =  UIViewContentModeCenter;
        //    self.imageview.contentMode = UIViewContentModeScaleAspectFill;
        [self.contentView addSubview:_imageview];
    }
    return self;
}

- (void)setImage:(UIImage *)image {
    _image = image;
    
    CGFloat proportion = image.size.width / image.size.height;
    
    UIImage *image2 = [self scaleToSize:image size:CGSizeMake(self.bounds.size.width, self.bounds.size.width / proportion)];
    
    self.imageview.image = image2;
    
}

- (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)newsize{
    UIGraphicsBeginImageContext(newsize);
    [img drawInRect:CGRectMake(0, 0, newsize.width, newsize.height)];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

@end


